/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.projet_s2;


/**
 *
 * @author Thuy
 */
public abstract class Ttsurfaces {
    abstract double surface();
    abstract void definirRevetement();
    
}
